import logo from './logo.svg';
import './App.css';
import Main from './views/Main';
import ProductForm from './components/ProductForm'
import ShowOne from './views/ShowOne'
import { Link, Switch, Route, Redirect } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <h1>Products</h1>
      <div>
        <Link to='/'>Home</Link> &nbsp;&nbsp;&nbsp;
        <Link to='/products/new'>Create</Link>
      </div>


      <Switch>
        <Route path='/products/new'>
          <div>
            <ProductForm />
          </div>
        </Route>
        <Route path='/products/:id'>
          <ShowOne/>
        </Route>
        <Route path='/products'>
          <Main />
        </Route>
        <Route path='/'>
          <ProductForm/>
          <hr/>
          <Main/>
        </Route>
      </Switch>
    </div>
  );
}

export default App;
