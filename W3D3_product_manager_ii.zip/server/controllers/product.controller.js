const Product = require("../models/Product.model");

module.exports = {
    //read
    findAll : (req, res)=> {
        Product.find()
        .then(allProducts => res.json(allProducts))
        .catch(err => res.json({error: err}))
    },
    findOne : (req, res) =>{
        Product.findById(req.params.id)
        .then(product => res.json(product))
        .catch(err => res.json({error: err}))
    },

    //create
    create : (req, res) =>{
        Product.create(req.body)
        .then(newProduct => res.json(newProduct))
        .catch(err => res.json({error: err}))
    },

    //update
    update : (req, res) =>{
        Product.findByIdAndUpdate(req.params.id)
    }
}