import React, {useState, useEffect} from 'react';
import {useParams} from 'react-router-dom';
import axios from 'axios';


const ShowOne = (props) =>{

    const {id} = useParams();

    const [thisProduct, setThisProduct] = useState({});

    useEffect(()=>{
        axios.get(`http://localhost:8000/api/products/${id}`)
        .then(res =>{
            console.log(res.data);
            setThisProduct(res.data)
        })
        .catch(err => console.log(err))
    }, [])

    return(
        <div>
            <h2>
                {thisProduct.title}
            </h2>
            <p>
                Price: {thisProduct.price}
            </p>
            <p>
                Description:  {thisProduct.description}
            </p>
            <p>
                Created: {Date(thisProduct.createdAt)}
            </p>
        </div>
    )
}

export default ShowOne;